---
c: Copyright (C) Daniel Stenberg, <daniel@haxx.se>, et al.
SPDX-License-Identifier: curl
Long: manual
Short: M
Help: Display the full manual
Category: curl
Added: 5.2
Multi: custom
See-also:
  - verbose
  - libcurl
  - trace
Example:
  - --manual
---

# `--manual`

Manual. Display the huge help text.
